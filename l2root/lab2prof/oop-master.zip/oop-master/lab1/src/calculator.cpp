#include "calculator.h"

int Calculator::add(int a, int b) {
    return a + b;
}