#ifndef LAB1_CALCULATOR_H
#define LAB1_CALCULATOR_H
namespace Calculator {

    /**
     * Adds two numbers and returns the result
     * a - the first number
     * b - the second number
     * returns the sum of a and b
     */
    int add(int a, int b);

}
#endif //LAB1_CALCULATOR_H