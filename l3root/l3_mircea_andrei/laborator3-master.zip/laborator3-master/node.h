//Aiordachioaei Andrei
class Node {
public:
    Node();
    Node(int v);
    ~Node();
    Node *left;
    Node *right;
    int value;

};