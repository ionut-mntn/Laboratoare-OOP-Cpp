//
// Created by User on 2/29/2020.
//

#ifndef LAB1_DIVISIBILITY_H
#define LAB1_DIVISIBILITY_H

namespace Divisibility
{
    /**
     * Finds greatest common divisior of two numbers
     * a, b - numbers to find gcd of
     * returns gcd of a and b
     */
    int gcd(int a, int b);
}

#endif //LAB1_DIVISIBILITY_H
