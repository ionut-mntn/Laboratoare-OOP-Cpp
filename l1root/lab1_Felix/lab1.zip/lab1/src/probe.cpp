/*
//
// Created by User on 2/29/2020.
//
#include <iostream>

//using std :: cout

int & f(int a)
{
    return a
}

int f2(int a)
{
    return a
}

int main()
{
    int nr = 2;
    std :: cout << f(nr);
    std :: cout << f(nr);
}
*/