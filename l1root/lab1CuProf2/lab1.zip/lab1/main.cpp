#include <iostream>
#include "calculator.h"

using namespace std;

int main() {
    cout << Calculator::add(1, 2) << endl;
    return 0;
}
