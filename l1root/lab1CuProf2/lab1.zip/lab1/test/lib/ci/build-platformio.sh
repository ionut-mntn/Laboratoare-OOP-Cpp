# run PlatformIO builds
platformio run
