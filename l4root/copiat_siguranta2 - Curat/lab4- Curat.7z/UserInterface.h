#pragma once
#include "Controller.h"
class UserInterface
{
public:
	UserInterface();

	void start();
};

